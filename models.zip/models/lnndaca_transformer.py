import torch
import torch.nn as nn
import math


# ==========================================================
# Positional Encoding (Learnable)
# ==========================================================

class LearnablePositionalEncoding(nn.Module):
    def __init__(self, max_len, d_model):
        super().__init__()
        self.pos_embedding = nn.Embedding(max_len, d_model)

    def forward(self, x):
        B, L, D = x.size()
        pos_ids = torch.arange(L, device=x.device).unsqueeze(0)
        pos_emb = self.pos_embedding(pos_ids)
        return x + pos_emb



# ==========================================================
# RNA / Protein Embedding with automatic truncation
# ==========================================================

class RNAEmbedding(nn.Module):
    def __init__(self, embed_dim, max_len):
        super().__init__()
        vocab = ["A", "U", "G", "C", "N"]
        self.char2idx = {c: i+1 for i, c in enumerate(vocab)}

        self.max_len = max_len
        self.embedding = nn.Embedding(len(vocab)+1, embed_dim, padding_idx=0)
        self.pos = LearnablePositionalEncoding(max_len, embed_dim)

    def forward(self, seq_batch):
        token_ids = []

        for seq in seq_batch:
            seq = seq[:self.max_len]                  # truncate
            ids = [self.char2idx.get(c.upper(), 0) for c in seq]
            token_ids.append(torch.tensor(ids))

        token_ids = nn.utils.rnn.pad_sequence(
            token_ids, batch_first=True, padding_value=0
        )

        x = self.embedding(token_ids.to(self.embedding.weight.device))
        x = self.pos(x)
        return x  # [B, Lr, D]


class ProteinEmbedding(nn.Module):
    def __init__(self, embed_dim, max_len):
        super().__init__()
        vocab = list("ACDEFGHIKLMNPQRSTVWY") + ["X"]
        self.char2idx = {c: i+1 for i, c in enumerate(vocab)}

        self.max_len = max_len
        self.embedding = nn.Embedding(len(vocab)+1, embed_dim, padding_idx=0)
        self.pos = LearnablePositionalEncoding(max_len, embed_dim)

    def forward(self, seq_batch):
        token_ids = []

        for seq in seq_batch:
            seq = seq[:self.max_len]              # truncate
            ids = [self.char2idx.get(c.upper(), 0) for c in seq]
            token_ids.append(torch.tensor(ids))

        token_ids = nn.utils.rnn.pad_sequence(
            token_ids, batch_first=True, padding_value=0
        )

        x = self.embedding(token_ids.to(self.embedding.weight.device))
        x = self.pos(x)
        return x  # [B, Lp, D]



# ==========================================================
# Transformer Encoder Block
# ==========================================================

class TransformerEncoderBlock(nn.Module):
    def __init__(self, embed_dim, num_heads, ff_mult=4, dropout=0.1):
        super().__init__()
        self.ln1 = nn.LayerNorm(embed_dim)
        self.ln2 = nn.LayerNorm(embed_dim)

        self.attn = nn.MultiheadAttention(
            embed_dim, num_heads, dropout=dropout, batch_first=True
        )

        self.ff = nn.Sequential(
            nn.Linear(embed_dim, embed_dim * ff_mult),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(embed_dim * ff_mult, embed_dim),
        )

        self.dropout = nn.Dropout(dropout)

    def forward(self, x):
        # Self-attention
        x_norm = self.ln1(x)
        attn_out, _ = self.attn(x_norm, x_norm, x_norm)
        x = x + self.dropout(attn_out)

        # Feed-forward
        x_norm = self.ln2(x)
        ff_out = self.ff(x_norm)
        x = x + self.dropout(ff_out)

        return x



class TransformerEncoder(nn.Module):
    def __init__(self, embed_dim, num_heads, num_layers):
        super().__init__()
        self.layers = nn.ModuleList([
            TransformerEncoderBlock(embed_dim, num_heads)
            for _ in range(num_layers)
        ])

    def forward(self, x):
        for layer in self.layers:
            x = layer(x)
        return x



# ==========================================================
# Cross Attention (Protein → RNA)
# ==========================================================

class CrossAttention(nn.Module):
    def __init__(self, embed_dim, num_heads):
        super().__init__()
        self.embed_dim = embed_dim
        self.num_heads = num_heads
        self.head_dim = embed_dim // num_heads

        assert embed_dim % num_heads == 0

        self.q_proj = nn.Linear(embed_dim, embed_dim)
        self.k_proj = nn.Linear(embed_dim, embed_dim)
        self.v_proj = nn.Linear(embed_dim, embed_dim)

        self.out_proj = nn.Linear(embed_dim, embed_dim)

        # adaptive temperature
        self.temp_bias = nn.Parameter(torch.zeros(1))

        # save data for visualization
        self.last_attn = None
        self.last_base_logits = None
        self.last_tau = None

    def forward(self, query, key, value):
        """
        query: Protein  [B, Lp, D]
        key:   RNA      [B, Lr, D]
        value: RNA      [B, Lr, D]
        """
        B, Lq, D = query.size()
        _, Lk, D = key.size()

        # project to heads
        Q = self.q_proj(query).view(B, Lq, self.num_heads, self.head_dim).transpose(1, 2)
        K = self.k_proj(key).view(B, Lk, self.num_heads, self.head_dim).transpose(1, 2)
        V = self.v_proj(value).view(B, Lk, self.num_heads, self.head_dim).transpose(1, 2)

        # ===== 1. adaptive temperature =====
        q_mean = Q.mean(dim=1).mean(dim=1)
        k_mean = K.mean(dim=1).mean(dim=1)
        sim = (q_mean * k_mean).sum(dim=-1).mean()
        tau = torch.sigmoid(sim + self.temp_bias) * math.sqrt(self.head_dim) + 1e-6

        # ===== 2. base attention logits (QK^T) =====
        base_logits = torch.matmul(Q, K.transpose(-1, -2))        # [B,H,Lq,Lk]

        # ===== 3. NEW: similarity bias between raw embeddings =====
        # sim_bias[b, i, j] = dot( protein_i , rna_j )
        sim_bias = torch.matmul(
            query,                          # [B,Lq,D]
            key.transpose(1,2)              # [B,D,Lk]
        ).unsqueeze(1)                       # → [B,1,Lq,Lk]

        # scale bias
        sim_bias = sim_bias / math.sqrt(self.embed_dim)

        # ===== 4. final attention logits =====
        attn_logits = base_logits / tau + sim_bias

        # ===== 5. attention weights =====
        attn = torch.softmax(attn_logits, dim=-1)

        # ===== 6. output =====
        out = torch.matmul(attn, V)
        out = out.transpose(1, 2).reshape(B, Lq, D)
        out = self.out_proj(out)

        # ===== 7. save for visualization =====
        self.last_attn = attn.detach().cpu()
        self.last_base_logits = base_logits.detach().cpu()
        self.last_tau = float(tau.detach().cpu())

        return out



# ==========================================================
# Full Model: LNNDACA_Transformer
# ==========================================================

class LNNDACA_Transformer(nn.Module):
    def __init__(self, embed_dim=128, heads=8,
                 Lr=500, Lp=600, enc_layers=2):
        super().__init__()

        # embeddings
        self.rna_emb = RNAEmbedding(embed_dim, Lr)
        self.pro_emb = ProteinEmbedding(embed_dim, Lp)

        # encoders
        self.rna_enc = TransformerEncoder(embed_dim, heads, enc_layers)
        self.pro_enc = TransformerEncoder(embed_dim, heads, enc_layers)

        # cross attention
        self.cross_attn = CrossAttention(embed_dim, heads)

        # pooling
        self.cls_rna = nn.Linear(embed_dim, embed_dim)
        self.cls_pro = nn.Linear(embed_dim, embed_dim)

        # classifier
        self.clf = nn.Sequential(
            nn.Linear(embed_dim * 2, 256),
            nn.ReLU(),
            nn.Dropout(0.3),
            nn.Linear(256, 1)
        )

    def forward(self, rna_seqs, pro_seqs):

        # ===== TRUNCATE LONG SEQUENCES HERE =====
        rna_seqs = [s[:500] for s in rna_seqs]
        pro_seqs = [s[:600] for s in pro_seqs]

        # ===== EMBEDDING =====
        rna = self.rna_emb(rna_seqs)
        pro = self.pro_emb(pro_seqs)

        # ===== SELF-ENCODERS =====
        rna = self.rna_enc(rna)
        pro = self.pro_enc(pro)

        # ===== CROSS-ATTENTION (Protein → RNA) =====
        pro2rna = self.cross_attn(pro, rna, rna)

        # ===== POOLING =====
        rna_vec = rna.mean(dim=1)
        pro_vec = pro2rna.mean(dim=1)

        fused = torch.cat([self.cls_rna(rna_vec), self.cls_pro(pro_vec)], dim=-1)

        logits = self.clf(fused)

        # ===== EXPORT ATTENTION =====
        attn = self.cross_attn.last_attn
        base_logits = self.cross_attn.last_base_logits
        tau = self.cross_attn.last_tau

        # return logits, (attn, base_logits, tau)
        return logits, (attn, base_logits, tau, rna, pro2rna)

